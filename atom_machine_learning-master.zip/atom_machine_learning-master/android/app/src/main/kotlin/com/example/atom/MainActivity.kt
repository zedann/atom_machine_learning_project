package com.example.atom

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
