class AppConstants {
  static const dropDownItemCount = 3;
  static const String baseUrl = 'http://192.168.1.3:3000/api/v1/users/';
  static const String signup = 'signup';
  static const String modelbaseurl = 'http://172.31.144.1:5001/';
  static const String predict = 'predict';
}