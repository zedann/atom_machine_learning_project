import 'package:flutter/material.dart';

class ColorManger {
  static Color? primary = Colors.grey[100];
  static const Color black = Colors.black;
  static const Color grey = Colors.grey;
  static const Color orange = Colors.orange;
  static const Color white = Color(0xFFFFFFFF);
}
