class Routes {
  static const String onboarding = '/onboarding';
  static const String homeScreen = '/homeScreen';
  static const String login = '/login';
  static const String signup = '/signup';
}
