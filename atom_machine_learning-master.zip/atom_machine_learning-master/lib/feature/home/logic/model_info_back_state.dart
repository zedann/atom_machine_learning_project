part of 'model_info_back_cubit.dart';


// abstract class BackModelInfoState {}
//
// class BackModelInfoInitialState extends BackModelInfoState {}
//
// class BackModelInfoLoadingState extends BackModelInfoState {}
//
// class BackModelInfoSuccessState extends BackModelInfoState {
//   final BackModelResponse backModelResponse;
//
//   BackModelInfoSuccessState({required this.backModelResponse});
// }
//
// class BackModelInfoFailureState extends BackModelInfoState {
//   final String error;
//
//   BackModelInfoFailureState({required this.error});
// }

